package com.example.bikersarcade;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView username=(TextView) findViewById(R.id.username);
        TextView password=(TextView) findViewById(R.id.password);

        MaterialButton loginbtn=(MaterialButton) findViewById(R.id.loginbtn);
        //devbrath and 1234
        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(username.getText().toString().equals("devbrath") && password.getText().toString().equals("1234")) {
                    //correct
                    Toast.makeText(MainActivity.this, "Login Successful",Toast.LENGTH_SHORT).show();
                    loginbtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            openBikersArcade();
                        }
                    });
                }else
                {
                    //incorrect
                    Toast.makeText(MainActivity.this, "Login Failed !",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public void openBikersArcade() {
        Intent intent = new Intent(this, BikersArcade.class);
        startActivity(intent);
    }
}
=