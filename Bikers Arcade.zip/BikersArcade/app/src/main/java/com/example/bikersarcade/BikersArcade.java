package com.example.bikersarcade;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class BikersArcade extends AppCompatActivity{

    private EditText brand;
    private EditText model;
    private Button submit;
    public static String m1;
    public static String m2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bikers_arcade);

        final EditText brandet = findViewById(R.id.brand);
        final EditText modelet = findViewById(R.id.model);
        Button btn = findViewById(R.id.submit);A

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 String comp=brandet.getText().toString();
                m1=comp;
                String model=modelet.getText().toString();
                m2=model;

                Intent intent=new Intent(BikersArcade.this, BikersArcade2.class);

                intent.putExtra( "BRAND", m1);
                intent.putExtra( "MODEL", m2);
                startActivity(intent);
            }
        });
    }
}