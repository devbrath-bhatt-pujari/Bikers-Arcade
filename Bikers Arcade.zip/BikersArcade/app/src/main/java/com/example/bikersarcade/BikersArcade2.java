package com.example.bikersarcade;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class BikersArcade2 extends AppCompatActivity{

    Button confbtn;
    Button editbtn;

    TextView brandTextView, modelTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bikers_arcade2);

        brandTextView=findViewById(R.id.brandview);
        modelTextView=findViewById(R.id.modelview);
        confbtn=findViewById(R.id.confirm);
        editbtn = findViewById(R.id.goback);

        String brand=getIntent().getStringExtra("Brand");
        String model=getIntent().getStringExtra("Model");

        brandTextView.setText(brand);
        modelTextView.setText(model);

        Intent intent = getIntent();
        String ibrand = intent.getStringExtra("BRAND");
        String imodel = intent.getStringExtra("MODEL");

        TextView infotv = findViewById(R.id.info);

        infotv.setText("Confirm Your Data:"+"\n\n\nBrand : " +ibrand+"\nModel : "+imodel);

        confbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(BikersArcade2.this, BikersArcade3.class);
                startActivity(intent);
            }
        });

        editbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(BikersArcade2.this, BikersArcade.class);
                startActivity(intent);
            }
        });
    }
}
